package com.example.administrador.proyecto.Http;

/**
 * Created by Administrador on 18/06/2016.
 */




import android.os.AsyncTask;
import android.util.Log;

import com.example.administrador.proyecto.Http.UsersService;
import com.example.administrador.proyecto.Model.User;
import com.example.administrador.proyecto.UserFragment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RequestUsersAsyncTask extends AsyncTask<Void, Void, List<User>> {

    private UserFragment fragment;

    public RequestUsersAsyncTask(UserFragment userFragment) {
        this.fragment = userFragment;
    }


    @Override
    protected List<User> doInBackground(Void... params) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://dip-androiducbv2.herokuapp.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        UsersService service = retrofit.create(UsersService.class);
        Call<List<User>> call = service.getAllUsers();

        try {
            Response<List<User>> response = call.execute();
            return response.body();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return new ArrayList<>();
    }

    /*
    @Override
    protected Void doInBackground(Void... params) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://dip-androiducbv2.herokuapp.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        UsersService service = retrofit.create( UsersService.class);

        Call<List<User>> users = service.getAllUsers();
        try {
            Response<List<User>> response = users.execute();
            List<User> list = response.body();
            Log.d("Main Activity", "Objects: " + list.size());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

*/
    @Override
    protected void onPostExecute(List<User> users) {
        fragment.getAdapter().clear();
        fragment.getAdapter().addAll(users);
    }
}
