package com.example.administrador.proyecto;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.administrador.proyecto.Activities.UserDetailActivity;
import com.example.administrador.proyecto.Adapters.UserAdapter;
import com.example.administrador.proyecto.Http.RequestUsersAsyncTask;
import com.example.administrador.proyecto.Model.User;

public class UserFragment extends Fragment {
    private ListView listView;
    private UserAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_user, container, false);
        // Inflate the layout for this fragment
        listView = (ListView)view.findViewById(R.id.users_list_view);
        adapter = new UserAdapter(getActivity());
        listView.setAdapter(adapter);

        //Ejecutamos el hilo
        RequestUsersAsyncTask task = new RequestUsersAsyncTask(this);
        task.execute();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                User item = adapter.getUser(i);

                Intent intent = new Intent(getContext(), UserDetailActivity.class);

                //Creamos la información a pasar entre actividades
                Bundle b = new Bundle();

                //b.putString("ID", String.valueOf(item.getId()));
                b.putString("TITLE", item.getUsername().toString());
                b.putString("CONTENT", item.getEmail().toString());

                //Añadimos la información al intent
                intent.putExtras(b);
                startActivity(intent);
            }
        });

        return view;
    }

    public UserAdapter getAdapter() {
        return adapter;
    }
}
