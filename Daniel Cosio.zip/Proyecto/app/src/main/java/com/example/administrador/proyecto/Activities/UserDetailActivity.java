package com.example.administrador.proyecto.Activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.administrador.proyecto.R;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class UserDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);


        //Recuperamos la información pasada en el intent
        Bundle bundle = this.getIntent().getExtras();

        //Mostramos la informacion

        TextView titleTextView = (TextView)this.findViewById(R.id.title_text);
        TextView contentTextView = (TextView)this.findViewById(R.id.content_text);

        ImageView imageUser = (ImageView)this.findViewById(R.id.user_image);
        /*
        URL url = null;

        try {
            url = new URL("https://robohash.org/similiqueomnisblanditiis.png?size=50x50/u0026set=set1");
            Bitmap bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
            imageUser.setImageBitmap(bmp);

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        */


        titleTextView.setText(bundle.getString("TITLE"));
        contentTextView.setText(bundle.getString("CONTENT"));
    }

    public void BackClick(View view) {

        Intent intent = new Intent(this, DashboardActivity.class);
        startActivity(intent);
    }
}
