package com.example.administrador.proyecto.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrador.proyecto.Http.LoginAsyncTask;
import com.example.administrador.proyecto.Model.User;
import com.example.administrador.proyecto.R;

public class PostDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_detail);


        //Recuperamos la información pasada en el intent
        Bundle bundle = this.getIntent().getExtras();

        //Mostramos la informacion

        TextView titleTextView = (TextView)this.findViewById(R.id.title_text);
        TextView contentTextView = (TextView)this.findViewById(R.id.content_text);

        titleTextView.setText(bundle.getString("TITLE"));
        contentTextView.setText(bundle.getString("CONTENT"));
    }

    public void BackClick(View view) {

            Intent intent = new Intent(this, DashboardActivity.class);
            startActivity(intent);
    }
}
