package com.example.administrador.proyecto.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.administrador.proyecto.Http.LoginAsyncTask;
import com.example.administrador.proyecto.Model.User;
import com.example.administrador.proyecto.R;

import java.io.IOException;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private String username = "";
    private String password = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Obtenemos los elementos del layout
        usernameEditText = (EditText)findViewById(R.id.username);
        passwordEditText = (EditText)findViewById(R.id.password);
    }

    public void loginClick(View view) {
        //Obtenemos el valor de los controles
        username = usernameEditText.getText().toString();
        password = passwordEditText.getText().toString();

        Log.d("LoginActivity", "You clicked me!");
        Log.d("LoginActivity", "Username: " + username);
        Log.d("LoginActivity", "Password: " + password);

        //Llamamos al servicio

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        LoginAsyncTask task = new LoginAsyncTask(this);
        task.execute(user);
    }

    public void ClearTextboxs(){
        //Vaciamos los controles
        usernameEditText.setText("");
        passwordEditText.setText("");
    }

    public void Redirect() {
        Intent intent = new Intent(this, DashboardActivity.class);
        startActivity(intent);
    }
}
